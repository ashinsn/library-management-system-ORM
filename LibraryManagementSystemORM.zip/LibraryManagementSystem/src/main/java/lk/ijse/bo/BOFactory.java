package lk.ijse.bo;

public class BOFactory {
}
