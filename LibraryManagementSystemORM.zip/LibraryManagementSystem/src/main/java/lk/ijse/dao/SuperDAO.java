package lk.ijse.dao;

public interface SuperDAO {

}
