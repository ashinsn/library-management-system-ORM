package lk.ijse.dao.custom;

import lk.ijse.dao.crudDAO;
import lk.ijse.entity.Admin;

public interface AdminSignupDAO extends crudDAO<Admin> {
}
